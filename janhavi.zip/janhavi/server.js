const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname)));

// Health check & status endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    services: {
      claude_ai: !!process.env.CLAUDE_API_KEY,
      google_sheets: !!(process.env.GOOGLE_SHEETS_ID && process.env.GOOGLE_PRIVATE_KEY)
    }
  });
});

// AI Financial Advice Endpoint (Claude Proxy + Offline Fallback)
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { question, financialContext } = req.body;

    if (!question || typeof question !== 'string') {
      return res.status(400).json({ error: 'Valid question parameter is required.' });
    }

    const apiKey = process.env.CLAUDE_API_KEY;

    // Build financial context string if provided
    let contextPrompt = '';
    if (financialContext) {
      contextPrompt = `\n\nUser's Financial Profile Snapshot:
- Monthly Income: ₹${financialContext.monthlyIncome || 'N/A'}
- Monthly Expenses: ₹${financialContext.monthlyExpenses || 'N/A'}
- Existing EMI: ₹${financialContext.existingEMI || 'N/A'}
- Credit Score: ${financialContext.creditScore || 'N/A'}
- Desired Loan Amount: ₹${financialContext.desiredLoanAmount || 'N/A'}
- Employment Type: ${financialContext.employmentType || 'N/A'}`;
    }

    // System prompt enforcing safety & educational scope
    const systemPrompt = `You are "FinVision AI", an expert educational BFSI financial assistant.
Rules you MUST strictly follow:
1. Explain financial concepts simply, concisely, and encouragingly.
2. Format answers using clean markdown (bullet points, bold highlights, short paragraphs).
3. Do NOT claim to be a bank, lender, credit bureau, or licensed financial advisor.
4. Do NOT promise or guarantee loan approvals, interest rates, or specific returns.
5. Provide actionable, practical educational guidance based on user financial metrics.
6. Always maintain a professional, helpful, fintech-focused tone.
7. End responses with a quick 1-sentence reminder that advice is for educational purposes.`;

    if (apiKey && apiKey !== 'your_claude_api_key_here') {
      try {
        const { Anthropic } = require('@anthropic-ai/sdk');
        const anthropic = new Anthropic({ apiKey });

        const message = await anthropic.messages.create({
          model: 'claude-3-5-sonnet-20240620',
          max_tokens: 800,
          system: systemPrompt,
          messages: [
            {
              role: 'user',
              content: `User Question: "${question}"${contextPrompt}`
            }
          ]
        });

        const reply = message.content[0].text;
        return res.json({
          success: true,
          answer: reply,
          source: 'claude_api'
        });
      } catch (apiError) {
        console.error('Claude API Error, falling back to smart AI engine:', apiError.message);
      }
    }

    // Smart Offline AI Fallback Generator
    const fallbackAnswer = generateSmartFallbackAdvice(question, financialContext);
    return res.json({
      success: true,
      answer: fallbackAnswer,
      source: 'offline_ai_engine',
      note: 'Operating in intelligent offline demo mode.'
    });

  } catch (err) {
    console.error('Server error in /api/ai/chat:', err);
    res.status(500).json({
      error: 'An error occurred while generating financial advice. Please try again.',
      details: err.message
    });
  }
});

// Google Sheets Integration Endpoint (with local storage fallback)
app.post('/api/sheets/submit', async (req, res) => {
  try {
    const submissionData = req.body;
    const sheetsId = process.env.GOOGLE_SHEETS_ID;
    const clientEmail = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
    const privateKey = process.env.GOOGLE_PRIVATE_KEY;

    if (sheetsId && clientEmail && privateKey) {
      try {
        const { google } = require('googleapis');
        const auth = new google.auth.JWT(
          clientEmail,
          null,
          privateKey.replace(/\\n/g, '\n'),
          ['https://www.googleapis.com/auth/spreadsheets']
        );

        const sheets = google.sheets({ version: 'v4', auth });
        const values = [
          [
            new Date().toISOString(),
            submissionData.fullName || 'Anonymous',
            submissionData.age || '',
            submissionData.employmentType || '',
            submissionData.monthlyIncome || '',
            submissionData.monthlyExpenses || '',
            submissionData.existingEMI || '',
            submissionData.desiredLoanAmount || '',
            submissionData.loanTenure || '',
            submissionData.creditScore || '',
            submissionData.eligibilityStatus || '',
            submissionData.estimatedEMI || ''
          ]
        ];

        await sheets.spreadsheets.values.append({
          spreadsheetId: sheetsId,
          range: 'Sheet1!A:L',
          valueInputOption: 'USER_ENTERED',
          resource: { values }
        });

        return res.json({
          success: true,
          mode: 'google_sheets',
          message: 'Data successfully recorded in Google Sheets.'
        });
      } catch (sheetsErr) {
        console.error('Google Sheets API error:', sheetsErr.message);
      }
    }

    // Fallback response instructing frontend to store locally
    return res.json({
      success: true,
      mode: 'local_storage_fallback',
      message: 'Google Sheets credentials not configured. Saved to browser storage locally.'
    });
  } catch (err) {
    console.error('Server error in /api/sheets/submit:', err);
    res.status(500).json({ error: 'Failed to process submission record.' });
  }
});

// Helper function for Smart Fallback AI responses
function generateSmartFallbackAdvice(question, ctx = {}) {
  const q = question.toLowerCase();
  const income = Number(ctx.monthlyIncome) || 50000;
  const expenses = Number(ctx.monthlyExpenses) || 20000;
  const emi = Number(ctx.existingEMI) || 5000;
  const score = Number(ctx.creditScore) || 750;
  const disposable = income - expenses - emi;

  if (q.includes('credit score') || q.includes('improve')) {
    return `### 📈 How to Improve Your Credit Score (${score} current baseline)

Here are 4 actionable steps to boost your credit profile:

1. **Maintain 100% On-Time Payments**: Timely payments account for 35% of your credit score. Set up auto-debit for your EMIs and credit cards.
2. **Keep Credit Utilization Below 30%**: Currently, using more than 30% of your credit limit signals financial stress to credit bureaus.
3. **Avoid Multiple Loan Applications**: Refrain from applying for several loans in a short duration to minimize hard inquiries.
4. **Maintain Healthy Credit Mix**: A balanced combination of secured (home/auto) and unsecured (credit card/personal) credit strengthens credit history.

*Note: This information is for educational purposes and is not a guarantee of score increase.*`;
  }

  if (q.includes('afford') || q.includes('loan')) {
    return `### 💡 Loan Affordability Analysis

Based on your profile:
- **Net Disposable Income**: ₹${disposable.toLocaleString('en-IN')}/month
- **Current Debt-to-Income (DTI)**: ${((emi / income) * 100).toFixed(1)}%

**Key Takeaways**:
- Financial experts recommend keeping your total EMIs (existing + new) under **40% to 50%** of your net monthly income.
- Your estimated maximum new EMI capacity is around **₹${Math.max(0, Math.round(disposable * 0.5)).toLocaleString('en-IN')}**.
- Always maintain an emergency fund covering at least **3–6 months** of essential living expenses before committing to a new loan.

*Note: Educational estimate only. Final approval depends on bank assessment.*`;
  }

  if (q.includes('reduce') || q.includes('reduce emi') || q.includes('lower emi')) {
    return `### 📉 Strategies to Lower Your Monthly EMI

1. **Opt for a Longer Tenure**: Extending your repayment period reduces your monthly EMI, though it increases total interest paid over time.
2. **Make Partial Pre-payments**: Applying bonuses or lump sums toward loan principal directly lowers future EMI burdens.
3. **Explore Balance Transfer**: Compare rates across lenders. Transferring your high-interest loan to a bank offering lower rates can significantly cut monthly outgo.
4. **Improve Credit Score**: A credit score above 750 places you in prime borrowing brackets for negotiated lower interest rates.

*Note: Educational guide only. Check lender pre-payment terms.*`;
  }

  if (q.includes('save') || q.includes('savings')) {
    return `### 💰 Monthly Savings Recommendations

With your current monthly income of **₹${income.toLocaleString('en-IN')}**:

1. **Apply the 50/30/20 Rule**:
   - **50% Needs**: Essential living costs & fixed bills (₹${(income * 0.5).toLocaleString('en-IN')})
   - **30% Wants**: Lifestyle & non-essentials (₹${(income * 0.3).toLocaleString('en-IN')})
   - **20% Savings/Investments**: Minimum recommended savings (₹${(income * 0.2).toLocaleString('en-IN')})
2. **Emergency Fund First**: Build a liquid buffer of **₹${(expenses * 4).toLocaleString('en-IN')}** in high-yield savings or liquid mutual funds.

*Note: General educational guidance, not formal financial advice.*`;
  }

  return `### 📊 AI Financial Analysis & Insights

Thank you for your inquiry! Here are key recommendations tailored to your profile:

- **Financial Health Summary**: You currently have a net monthly disposable income of **₹${disposable.toLocaleString('en-IN')}**.
- **Credit Standing**: A score of **${score}** provides a strong foundation for competitive loan interest rates.
- **Smart Debt Strategy**: Prioritize paying off high-interest debt first while maintaining a 20% monthly savings rate.

Feel free to ask more specific questions about interest rates, loan tenures, or credit improvement strategies!

*Note: AI-generated guidance is strictly for educational assessment.*`;
}

// Fallback route serving main index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`  AI LOAN ELIGIBILITY CHECKER - BFSI PLATFORM    `);
  console.log(`==================================================`);
  console.log(` Server running on http://localhost:${PORT}`);
  console.log(` Claude AI status: ${process.env.CLAUDE_API_KEY ? 'CONFIGURED' : 'DEMO MODE (Smart Fallback)'}`);
  console.log(` Google Sheets status: ${process.env.GOOGLE_SHEETS_ID ? 'CONFIGURED' : 'LOCAL STORAGE FALLBACK'}`);
  console.log(`==================================================`);
});
