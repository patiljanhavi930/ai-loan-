/**
 * AI LOAN ELIGIBILITY CHECKER - LOAN ENGINE (LIGHT THEME)
 */

document.addEventListener('DOMContentLoaded', () => {
  const loanForm = document.getElementById('loan-eligibility-form');
  const demoBtn = document.getElementById('btn-try-demo-loan');

  if (loanForm) {
    loanForm.addEventListener('submit', handleLoanCalculation);
  }

  if (demoBtn) {
    demoBtn.addEventListener('click', populateDemoLoanData);
  }
});

// Demo Data Autofill as requested in Requirement #20
function populateDemoLoanData() {
  document.getElementById('loan-name').value = 'Rahul Sharma';
  document.getElementById('loan-age').value = '25';
  document.getElementById('loan-employment').value = 'salaried';
  document.getElementById('loan-income').value = '50000';
  document.getElementById('loan-expenses').value = '20000';
  document.getElementById('loan-existing-emi').value = '5000';
  document.getElementById('loan-amount').value = '500000';
  document.getElementById('loan-tenure').value = '5'; // 5 years
  document.getElementById('loan-rate').value = '10';
  document.getElementById('loan-score').value = '750';

  showToast('Demo data populated successfully!', 'info');
}

function handleLoanCalculation(e) {
  e.preventDefault();

  const name = document.getElementById('loan-name').value.trim() || 'Valued User';
  const ageInput = document.getElementById('loan-age');
  const incomeInput = document.getElementById('loan-income');
  const expensesInput = document.getElementById('loan-expenses');
  const emiInput = document.getElementById('loan-existing-emi');
  const amountInput = document.getElementById('loan-amount');
  const tenureInput = document.getElementById('loan-tenure');
  const rateInput = document.getElementById('loan-rate');
  const scoreInput = document.getElementById('loan-score');
  const employmentType = document.getElementById('loan-employment').value;

  // Validate form fields
  const isValidAge = validateField(ageInput, 'age');
  const isValidIncome = validateField(incomeInput, 'income');
  const isValidExpenses = validateField(expensesInput, 'expenses');
  const isValidEMI = validateField(emiInput, 'existingEMI');
  const isValidAmount = validateField(amountInput, 'desiredLoan');
  const isValidRate = validateField(rateInput, 'interestRate');
  const isValidScore = validateField(scoreInput, 'creditScore');

  if (!isValidAge || !isValidIncome || !isValidExpenses || !isValidEMI || !isValidAmount || !isValidRate || !isValidScore) {
    showToast('Please correct the errors highlighted in the form.', 'error');
    return;
  }

  const income = Number(incomeInput.value);
  const expenses = Number(expensesInput.value);
  const existingEMI = Number(emiInput.value);
  const desiredLoan = Number(amountInput.value);
  const tenureYears = Number(tenureInput.value);
  const tenureMonths = tenureYears * 12;
  const annualRate = Number(rateInput.value);
  const creditScore = Number(scoreInput.value);

  // 1. Math Calculations
  const monthlyRate = annualRate / (12 * 100);
  const disposableIncome = Math.max(0, income - expenses - existingEMI);
  const dti = (existingEMI / income) * 100;

  // Monthly EMI for desired loan using standard formula
  const emiFactor = Math.pow(1 + monthlyRate, tenureMonths);
  const estimatedEMI = Math.round(desiredLoan * monthlyRate * emiFactor / (emiFactor - 1));

  // Max EMI capability assuming 50% max allowable total DTI
  const maxAllowableTotalEMI = income * 0.50;
  const maxNewEMICapacity = Math.max(0, maxAllowableTotalEMI - existingEMI);

  // Reverse calculate max eligible loan amount based on max new EMI capacity
  const maxEligibleLoan = Math.round((maxNewEMICapacity * (emiFactor - 1)) / (monthlyRate * emiFactor));

  // 2. Status Determination
  let status = 'Likely Eligible';
  let badgeClass = 'badge-eligible';
  let statusIcon = '✓';
  let statusReason = 'Strong financial profile with healthy disposable income and excellent credit history.';

  if (dti > 45 || creditScore < 650 || estimatedEMI > disposableIncome) {
    status = 'Needs Improvement';
    badgeClass = 'badge-warning';
    statusIcon = '⚠';
    statusReason = 'Existing debt or credit score reduces immediate loan eligibility. Lowering current EMIs will improve your score.';
  } else if (dti > 30 || creditScore < 720 || estimatedEMI > disposableIncome * 0.7) {
    status = 'Potentially Eligible';
    badgeClass = 'badge-potential';
    statusIcon = 'ℹ';
    statusReason = 'Good profile, though lenders may require additional documentation or co-applicant guarantee.';
  }

  // 3. Render Result Card
  const resultContainer = document.getElementById('loan-result-container');
  resultContainer.innerHTML = `
    <div class="glass-card" style="margin-top: 2rem;">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem; margin-bottom:1.5rem;">
        <div>
          <span style="color:var(--text-muted); font-size:0.85rem;">Loan Assessment for ${sanitizeInput(name)}</span>
          <h3 style="font-size:1.5rem; margin-top:0.25rem; color:#0F172A;">Eligibility Result</h3>
        </div>
        <span class="result-badge ${badgeClass}">${statusIcon} ${status}</span>
      </div>

      <p style="color:var(--text-secondary); font-size:0.95rem; margin-bottom:1.5rem;">${statusReason}</p>

      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-label">Estimated Eligible Loan</div>
          <div class="metric-value cyan" id="res-max-loan">${formatINR(maxEligibleLoan)}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">Estimated Monthly EMI</div>
          <div class="metric-value green" id="res-emi">${formatINR(estimatedEMI)}</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">Debt-to-Income (DTI)</div>
          <div class="metric-value ${dti > 40 ? 'amber' : 'purple'}">${dti.toFixed(1)}%</div>
        </div>
        <div class="metric-card">
          <div class="metric-label">Net Disposable Income</div>
          <div class="metric-value cyan">${formatINR(disposableIncome)}/mo</div>
        </div>
      </div>

      <div style="background:#F8FAFC; border-radius:var(--radius-md); padding:1.25rem; border:1px solid var(--border-glass); margin-bottom:1.5rem;">
        <h4 style="font-size:1rem; margin-bottom:0.75rem; color:var(--primary-blue);">Risk Indicators & Health Summary</h4>
        <ul style="list-style:none; display:flex; flex-direction:column; gap:0.5rem; font-size:0.9rem; color:var(--text-secondary);">
          <li>• <strong>Income Cushion:</strong> ${disposableIncome >= estimatedEMI ? 'Sufficient disposable margin to support estimated EMI.' : 'Tight disposable margin; consider extending tenure.'}</li>
          <li>• <strong>Credit Standing:</strong> Score of ${creditScore} puts you in the ${creditScore >= 750 ? 'Prime' : creditScore >= 650 ? 'Standard' : 'Subprime'} tier.</li>
          <li>• <strong>DTI Stress:</strong> Existing EMIs represent ${dti.toFixed(1)}% of total monthly gross earnings.</li>
        </ul>
      </div>

      <div style="background:rgba(217, 119, 6, 0.08); border:1px solid rgba(217, 119, 6, 0.25); border-radius:var(--radius-md); padding:1rem 1.25rem; font-size:0.85rem; color:var(--text-secondary);">
        <strong>Financial Disclaimer:</strong> This result is an educational estimate based on user-provided inputs. It does not represent guaranteed loan approval, final interest rate offers, or binding bank commitments.
      </div>
    </div>
  `;

  resultContainer.scrollIntoView({ behavior: 'smooth' });

  // Update Global Dashboard Metrics if dashboard module exists
  if (window.updateDashboardMetrics) {
    window.updateDashboardMetrics({
      income,
      expenses,
      existingEMI,
      disposableIncome,
      creditScore,
      maxEligibleLoan,
      estimatedEMI
    });
  }

  // Record submission to Google Sheets API / Local Storage bridge
  if (window.submitToSheets) {
    window.submitToSheets({
      fullName: name,
      age: ageInput.value,
      employmentType,
      monthlyIncome: income,
      monthlyExpenses: expenses,
      existingEMI,
      desiredLoanAmount: desiredLoan,
      loanTenure: tenureYears,
      creditScore,
      eligibilityStatus: status,
      estimatedEMI
    });
  }

  showToast('Eligibility calculated successfully!', 'success');
}
