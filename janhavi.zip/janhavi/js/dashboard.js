/**
 * AI LOAN ELIGIBILITY CHECKER - FINANCIAL DASHBOARD MODULE
 */

window.updateDashboardMetrics = function(metrics) {
  const dashIncome = document.getElementById('dash-income');
  const dashExpenses = document.getElementById('dash-expenses');
  const dashEMI = document.getElementById('dash-emi');
  const dashDisposable = document.getElementById('dash-disposable');
  const dashCredit = document.getElementById('dash-credit');
  const dashLoanLimit = document.getElementById('dash-loan-limit');
  const dashHealthBar = document.getElementById('dash-health-bar');
  const dashHealthScore = document.getElementById('dash-health-score');

  if (dashIncome) dashIncome.textContent = formatINR(metrics.income);
  if (dashExpenses) dashExpenses.textContent = formatINR(metrics.expenses);
  if (dashEMI) dashEMI.textContent = formatINR(metrics.existingEMI);
  if (dashDisposable) dashDisposable.textContent = formatINR(metrics.disposableIncome);
  if (dashCredit) dashCredit.textContent = metrics.creditScore;
  if (dashLoanLimit) dashLoanLimit.textContent = formatINR(metrics.maxEligibleLoan);

  // Compute Overall Financial Health Score (0 - 100)
  const dti = (metrics.existingEMI / metrics.income) * 100 || 0;
  const savingsRatio = ((metrics.disposableIncome / metrics.income) * 100) || 0;
  
  let healthScore = 50; // Base score
  if (metrics.creditScore >= 750) healthScore += 25;
  else if (metrics.creditScore >= 650) healthScore += 15;
  
  if (dti < 30) healthScore += 15;
  else if (dti > 50) healthScore -= 15;

  if (savingsRatio >= 20) healthScore += 10;

  healthScore = Math.max(10, Math.min(100, Math.round(healthScore)));

  if (dashHealthBar) dashHealthBar.style.width = `${healthScore}%`;
  if (dashHealthScore) dashHealthScore.textContent = `${healthScore}/100`;
};
