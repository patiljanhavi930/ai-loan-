/**
 * AI LOAN ELIGIBILITY CHECKER - UTILITIES & HELPERS
 */

// Format numbers into Indian Rupee (INR) currency format (e.g. ₹5,00,000)
function formatINR(amount) {
  if (isNaN(amount) || amount === null || amount === undefined) return '₹0';
  const num = Math.round(Number(amount));
  return '₹' + num.toLocaleString('en-IN');
}

// Convert INR formatted text string back to clean float
function parseINR(val) {
  if (!val) return 0;
  return parseFloat(String(val).replace(/[^0-9.-]+/g, '')) || 0;
}

// Toast notification engine
function showToast(message, type = 'info', duration = 4000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const iconMap = {
    success: '✓',
    info: 'ℹ',
    warning: '⚠',
    error: '✕'
  };

  toast.innerHTML = `
    <span style="font-weight:bold; font-size:1.1rem;">${iconMap[type] || 'ℹ'}</span>
    <span>${sanitizeInput(message)}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(50px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// Animate numbers counting up smoothly
function animateCounter(element, targetValue, isCurrency = true, duration = 1000) {
  if (!element) return;
  const start = 0;
  const target = Number(targetValue);
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease-out quadratic function
    const easeProgress = progress * (2 - progress);
    const currentValue = Math.round(start + (target - start) * easeProgress);

    element.textContent = isCurrency ? formatINR(currentValue) : currentValue.toLocaleString('en-IN');

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

// Basic XSS Sanitizer for rendering user text
function sanitizeInput(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[&<>"']/g, function(m) {
    return {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    }[m];
  });
}
