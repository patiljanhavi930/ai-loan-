/**
 * AI LOAN ELIGIBILITY CHECKER - DATA VALIDATION MODULE
 */

const ValidationRules = {
  age: { min: 18, max: 80, message: 'Age must be between 18 and 80 years.' },
  income: { min: 1, message: 'Monthly income must be greater than ₹0.' },
  expenses: { min: 0, message: 'Expenses cannot be negative.' },
  existingEMI: { min: 0, message: 'Existing EMI cannot be negative.' },
  desiredLoan: { min: 1000, message: 'Desired loan amount must be at least ₹1,000.' },
  tenure: { min: 1, max: 360, message: 'Tenure must be between 1 and 360 months (or 30 years).' },
  interestRate: { min: 0.1, max: 50, message: 'Interest rate must be between 0.1% and 50% per annum.' },
  creditScore: { min: 300, max: 850, message: 'Credit score must be between 300 and 850.' }
};

function validateField(inputElement, ruleKey) {
  const value = Number(inputElement.value);
  const rule = ValidationRules[ruleKey];
  const errorElement = document.getElementById(`${inputElement.id}-error`);

  if (!rule) return true;

  let isValid = true;
  let errorMsg = '';

  if (isNaN(value) || inputElement.value === '') {
    isValid = false;
    errorMsg = 'This field is required.';
  } else if (rule.min !== undefined && value < rule.min) {
    isValid = false;
    errorMsg = rule.message;
  } else if (rule.max !== undefined && value > rule.max) {
    isValid = false;
    errorMsg = rule.message;
  }

  if (!isValid) {
    inputElement.classList.add('is-invalid');
    if (errorElement) {
      errorElement.textContent = errorMsg;
      errorElement.classList.add('visible');
    }
  } else {
    inputElement.classList.remove('is-invalid');
    if (errorElement) {
      errorElement.classList.remove('visible');
    }
  }

  return isValid;
}

function clearFormErrors(formElement) {
  const inputs = formElement.querySelectorAll('.form-input, .form-select');
  inputs.forEach(input => {
    input.classList.remove('is-invalid');
    const err = document.getElementById(`${input.id}-error`);
    if (err) err.classList.remove('visible');
  });
}
