/**
 * AI LOAN ELIGIBILITY CHECKER - MAIN APPLICATION CONTROLLER
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initMobileMenu();
  initTabSwitching();
});

// Tab Switcher Function
function switchTab(tabId) {
  const allTabs = document.querySelectorAll('.tab-content');
  const allNavLinks = document.querySelectorAll('.nav-link');

  allTabs.forEach(tab => {
    tab.classList.remove('active');
  });

  allNavLinks.forEach(link => {
    link.classList.remove('active');
    if (link.dataset.tab === tabId) {
      link.classList.add('active');
    }
  });

  const targetTab = document.getElementById(`tab-${tabId}`);
  if (targetTab) {
    targetTab.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Close mobile navigation drawer if open
  const navLinks = document.getElementById('nav-links');
  if (navLinks) navLinks.classList.remove('active');
}

function initTabSwitching() {
  const navLinks = document.querySelectorAll('.nav-link[data-tab]');
  const actionBtns = document.querySelectorAll('[data-switch-tab]');

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const tabId = link.dataset.tab;
      switchTab(tabId);
    });
  });

  actionBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const tabId = btn.dataset.switchTab;
      switchTab(tabId);
    });
  });
}

function initMobileMenu() {
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const navLinks = document.getElementById('nav-links');

  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  }
}

function initNavigation() {
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 40) {
      navbar.style.background = 'rgba(5, 8, 22, 0.95)';
      navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.5)';
    } else {
      navbar.style.background = 'rgba(5, 8, 22, 0.75)';
      navbar.style.boxShadow = 'none';
    }
  });
}
