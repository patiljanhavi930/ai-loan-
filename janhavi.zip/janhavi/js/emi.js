/**
 * AI LOAN ELIGIBILITY CHECKER - EMI CALCULATOR ENGINE (LIGHT THEME)
 */

document.addEventListener('DOMContentLoaded', () => {
  const emiForm = document.getElementById('emi-calculator-form');
  const printBtn = document.getElementById('btn-print-emi');

  if (emiForm) {
    emiForm.addEventListener('submit', handleEMICalculation);
  }

  if (printBtn) {
    printBtn.addEventListener('click', printAMSchedule);
  }
});

function handleEMICalculation(e) {
  if (e) e.preventDefault();

  const amountInput = document.getElementById('emi-amount-input');
  const rateInput = document.getElementById('emi-rate-input');
  const tenureInput = document.getElementById('emi-tenure-input');
  const tenureType = document.getElementById('emi-tenure-type').value;

  const isValidAmount = validateField(amountInput, 'desiredLoan');
  const isValidRate = validateField(rateInput, 'interestRate');
  const isValidTenure = validateField(tenureInput, 'tenure');

  if (!isValidAmount || !isValidRate || !isValidTenure) {
    showToast('Please check your EMI inputs.', 'error');
    return;
  }

  const P = Number(amountInput.value);
  const annualRate = Number(rateInput.value);
  const tenureVal = Number(tenureInput.value);
  const N = tenureType === 'years' ? tenureVal * 12 : tenureVal;

  const R = annualRate / (12 * 100);

  // EMI formula
  const emiFactor = Math.pow(1 + R, N);
  const EMI = Math.round(P * R * emiFactor / (emiFactor - 1));
  const totalPayment = EMI * N;
  const totalInterest = totalPayment - P;

  // Render Metric Outputs
  animateCounter(document.getElementById('emi-res-monthly'), EMI, true);
  animateCounter(document.getElementById('emi-res-principal'), P, true);
  animateCounter(document.getElementById('emi-res-interest'), totalInterest, true);
  animateCounter(document.getElementById('emi-res-total'), totalPayment, true);

  // Draw Canvas Donut Chart
  renderEMIChart(P, totalInterest);

  // Generate Amortization Table
  generateAmortizationTable(P, R, N, EMI);

  const resultsSection = document.getElementById('emi-results-section');
  if (resultsSection) {
    resultsSection.style.display = 'block';
    resultsSection.scrollIntoView({ behavior: 'smooth' });
  }

  showToast('EMI schedule generated!', 'success');
}

// Canvas-based Donut Chart Renderer (Principal vs Interest) for Light Theme
function renderEMIChart(principal, interest) {
  const canvas = document.getElementById('emi-donut-chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const total = principal + interest;

  ctx.clearRect(0, 0, width, height);

  const centerX = width / 2;
  const centerY = height / 2;
  const outerRadius = 85;
  const innerRadius = 55;

  const principalAngle = (principal / total) * (2 * Math.PI);
  const interestAngle = (interest / total) * (2 * Math.PI);

  // Draw Principal Arc (Royal Blue / Sky Blue)
  ctx.beginPath();
  ctx.arc(centerX, centerY, outerRadius, -Math.PI / 2, -Math.PI / 2 + principalAngle);
  ctx.arc(centerX, centerY, innerRadius, -Math.PI / 2 + principalAngle, -Math.PI / 2, true);
  ctx.closePath();
  const blueGrad = ctx.createLinearGradient(0, 0, width, height);
  blueGrad.addColorStop(0, '#2563EB');
  blueGrad.addColorStop(1, '#0284C7');
  ctx.fillStyle = blueGrad;
  ctx.fill();

  // Draw Interest Arc (Violet / Purple)
  ctx.beginPath();
  ctx.arc(centerX, centerY, outerRadius, -Math.PI / 2 + principalAngle, -Math.PI / 2 + principalAngle + interestAngle);
  ctx.arc(centerX, centerY, innerRadius, -Math.PI / 2 + principalAngle + interestAngle, -Math.PI / 2 + principalAngle, true);
  ctx.closePath();
  const purpleGrad = ctx.createLinearGradient(0, 0, width, height);
  purpleGrad.addColorStop(0, '#7C3AED');
  purpleGrad.addColorStop(1, '#D946EF');
  ctx.fillStyle = purpleGrad;
  ctx.fill();

  // Center Text Ratio (Dark Slate Text)
  const principalPercent = Math.round((principal / total) * 100);
  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 16px "Plus Jakarta Sans", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(`${principalPercent}% Principal`, centerX, centerY);
}

// Generate Month-by-Month Amortization Table
function generateAmortizationTable(P, R, N, EMI) {
  const tbody = document.getElementById('amortization-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';

  let balance = P;

  for (let month = 1; month <= N; month++) {
    const interestForMonth = Math.round(balance * R);
    let principalForMonth = EMI - interestForMonth;

    if (month === N || balance < principalForMonth) {
      principalForMonth = balance;
    }

    balance = Math.max(0, balance - principalForMonth);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>Month ${month}</td>
      <td style="color:var(--primary-blue); font-weight:600;">${formatINR(principalForMonth)}</td>
      <td style="color:var(--accent-purple);">${formatINR(interestForMonth)}</td>
      <td style="font-weight:600;">${formatINR(balance)}</td>
    `;
    tbody.appendChild(tr);
  }
}

// Print / PDF Export Schedule
function printAMSchedule() {
  window.print();
}
