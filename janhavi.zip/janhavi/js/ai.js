/**
 * AI LOAN ELIGIBILITY CHECKER - AI ASSISTANT MODULE (CLAUDE AI PROXY)
 */

document.addEventListener('DOMContentLoaded', () => {
  const chatForm = document.getElementById('ai-chat-form');
  const chatInput = document.getElementById('ai-chat-input');
  const quickChips = document.querySelectorAll('.prompt-chip');

  if (chatForm) {
    chatForm.addEventListener('submit', handleAIChatSubmit);
  }

  quickChips.forEach(chip => {
    chip.addEventListener('click', () => {
      if (chatInput) {
        chatInput.value = chip.textContent.trim();
        handleAIChatSubmit(new Event('submit'));
      }
    });
  });
});

async function handleAIChatSubmit(e) {
  if (e) e.preventDefault();

  const chatInput = document.getElementById('ai-chat-input');
  const chatMessages = document.getElementById('ai-chat-messages');

  if (!chatInput || !chatMessages) return;

  const question = chatInput.value.trim();
  if (!question) return;

  // Append User Message to Chat UI
  appendChatMessage(chatMessages, question, 'user');
  chatInput.value = '';

  // Append Typing Indicator Bubble
  const typingBubble = document.createElement('div');
  typingBubble.className = 'chat-bubble ai';
  typingBubble.id = 'ai-typing-indicator';
  typingBubble.innerHTML = `
    <div class="typing-indicator">
      <span style="font-size:0.85rem; color:var(--text-muted); margin-right:6px;">FinVision AI is thinking</span>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>
  `;
  chatMessages.appendChild(typingBubble);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  // Retrieve current financial snapshot from DOM or local state if filled
  const financialContext = {
    monthlyIncome: document.getElementById('loan-income')?.value || '',
    monthlyExpenses: document.getElementById('loan-expenses')?.value || '',
    existingEMI: document.getElementById('loan-existing-emi')?.value || '',
    creditScore: document.getElementById('loan-score')?.value || '',
    desiredLoanAmount: document.getElementById('loan-amount')?.value || '',
    employmentType: document.getElementById('loan-employment')?.value || ''
  };

  try {
    const response = await fetch('/api/ai/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, financialContext })
    });

    const data = await response.json();
    typingBubble.remove();

    if (data && data.success && data.answer) {
      appendChatMessage(chatMessages, data.answer, 'ai');
    } else {
      appendChatMessage(chatMessages, data.error || 'Sorry, I am unable to answer right now. Please try again.', 'ai');
    }
  } catch (err) {
    console.error('Error contacting AI Proxy:', err);
    typingBubble.remove();
    appendChatMessage(
      chatMessages,
      '### ⚠️ Network Error\nUnable to establish connection with the AI financial service. Please verify your internet connection or try again shortly.',
      'ai'
    );
  }
}

function appendChatMessage(container, text, sender) {
  const bubble = document.createElement('div');
  bubble.className = `chat-bubble ${sender}`;

  if (sender === 'ai') {
    bubble.innerHTML = parseMarkdownToHTML(text);
  } else {
    bubble.textContent = text;
  }

  container.appendChild(bubble);
  container.scrollTop = container.scrollHeight;
}

// Basic Markdown to HTML renderer for clean AI responses
function parseMarkdownToHTML(markdownText) {
  if (!markdownText) return '';
  let html = sanitizeInput(markdownText);

  // Headers
  html = html.replace(/^### (.*$)/gim, '<h4 style="color:var(--primary-cyan); font-size:1.05rem; margin:0.75rem 0 0.4rem 0;">$1</h4>');
  html = html.replace(/^## (.*$)/gim, '<h3 style="color:var(--text-white); font-size:1.15rem; margin:0.85rem 0 0.5rem 0;">$1</h3>');

  // Bold text
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--text-white);">$1</strong>');
  
  // Bullet lists
  html = html.replace(/^\s*[\-\*]\s+(.*$)/gim, '<li style="margin-left:1.25rem; margin-bottom:0.25rem;">$1</li>');
  html = html.replace(/(<li.*<\/li>)/gim, '<ul style="margin:0.5rem 0; padding-left:0.5rem;">$1</ul>');

  // Paragraph breaks
  html = html.replace(/\n\n/g, '<br/><br/>');

  return html;
}
