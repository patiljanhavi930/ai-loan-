/**
 * AI LOAN ELIGIBILITY CHECKER - CREDIT SCORE ANALYZER (LIGHT THEME)
 */

document.addEventListener('DOMContentLoaded', () => {
  const creditForm = document.getElementById('credit-analyzer-form');
  if (creditForm) {
    creditForm.addEventListener('submit', handleCreditAnalysis);
  }
});

function getCreditCategory(score) {
  if (score >= 800) return { category: 'Excellent', color: '#10B981', class: 'green' };
  if (score >= 740) return { category: 'Very Good', color: '#2563EB', class: 'cyan' };
  if (score >= 670) return { category: 'Good', color: '#0284C7', class: 'cyan' };
  if (score >= 580) return { category: 'Fair', color: '#D97706', class: 'amber' };
  return { category: 'Poor', color: '#EF4444', class: 'danger' };
}

function handleCreditAnalysis(e) {
  e.preventDefault();

  const scoreInput = document.getElementById('credit-score-input');
  const utilInput = document.getElementById('credit-util-input');
  const loansInput = document.getElementById('credit-loans-input');
  const cardsInput = document.getElementById('credit-cards-input');
  const historyInput = document.getElementById('credit-history-input');
  const inquiriesInput = document.getElementById('credit-inquiries-input');

  const isValidScore = validateField(scoreInput, 'creditScore');

  if (!isValidScore) {
    showToast('Please enter a valid credit score (300-850).', 'error');
    return;
  }

  const score = Number(scoreInput.value);
  const utilization = Number(utilInput.value) || 30;
  const activeLoans = Number(loansInput.value) || 1;
  const creditCards = Number(cardsInput.value) || 1;
  const historyYears = Number(historyInput.value) || 3;
  const inquiries = Number(inquiriesInput.value) || 0;

  const { category, color, class: colorClass } = getCreditCategory(score);

  // Calculate gauge offset (Total circumference arc ~ 440)
  const normalizedRatio = Math.max(0, Math.min(1, (score - 300) / 550));
  const dashOffset = Math.round(440 - (normalizedRatio * 440));

  const resultContainer = document.getElementById('credit-result-container');
  resultContainer.innerHTML = `
    <div class="glass-card" style="margin-top:2rem;">
      <div class="section-header" style="margin-bottom:2rem;">
        <h3 style="font-size:1.75rem; color:#0F172A;">Credit Score Health Breakdown</h3>
        <p style="color:var(--text-secondary);">Empirical factor analysis based on credit bureau metrics</p>
      </div>

      <!-- SVG Radial Meter -->
      <div class="gauge-wrapper">
        <svg class="gauge-svg" viewBox="0 0 200 160">
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#EF4444"/>
              <stop offset="50%" stop-color="#D97706"/>
              <stop offset="100%" stop-color="#10B981"/>
            </linearGradient>
          </defs>
          <path class="gauge-bg" d="M 30 140 A 70 70 0 1 1 170 140"/>
          <path class="gauge-fill" id="gauge-arc" d="M 30 140 A 70 70 0 1 1 170 140" style="stroke-dashoffset: 440;"/>
        </svg>
        <div class="gauge-center-text">
          <div class="gauge-score" id="gauge-score-val">300</div>
          <div class="gauge-category" style="color:${color};">${category}</div>
        </div>
      </div>

      <!-- Key Credit Factors Grid -->
      <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:1.25rem; margin:2rem 0;">
        <div style="background:#F8FAFC; border:1px solid var(--border-glass); padding:1rem; border-radius:var(--radius-md);">
          <div style="display:flex; justify-content:space-between; font-size:0.9rem; margin-bottom:0.35rem; color:#0F172A;">
            <span>Payment History (35%)</span>
            <span style="color:${score >= 700 ? '#10B981' : '#D97706'}; font-weight:bold;">${score >= 700 ? 'Excellent' : 'Needs Attention'}</span>
          </div>
          <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${Math.min(100, (score/850)*100)}%;"></div></div>
        </div>

        <div style="background:#F8FAFC; border:1px solid var(--border-glass); padding:1rem; border-radius:var(--radius-md);">
          <div style="display:flex; justify-content:space-between; font-size:0.9rem; margin-bottom:0.35rem; color:#0F172A;">
            <span>Credit Utilization (30%)</span>
            <span style="color:${utilization <= 30 ? '#10B981' : '#EF4444'}; font-weight:bold;">${utilization}%</span>
          </div>
          <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${Math.min(100, utilization)}%; background:${utilization > 30 ? '#EF4444' : '#10B981'};"></div></div>
        </div>

        <div style="background:#F8FAFC; border:1px solid var(--border-glass); padding:1rem; border-radius:var(--radius-md);">
          <div style="display:flex; justify-content:space-between; font-size:0.9rem; margin-bottom:0.35rem; color:#0F172A;">
            <span>Credit History Age (15%)</span>
            <span style="color:${historyYears >= 4 ? '#10B981' : '#D97706'}; font-weight:bold;">${historyYears} Years</span>
          </div>
          <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${Math.min(100, (historyYears/10)*100)}%;"></div></div>
        </div>

        <div style="background:#F8FAFC; border:1px solid var(--border-glass); padding:1rem; border-radius:var(--radius-md);">
          <div style="display:flex; justify-content:space-between; font-size:0.9rem; margin-bottom:0.35rem; color:#0F172A;">
            <span>Recent Inquiries (10%)</span>
            <span style="color:${inquiries <= 2 ? '#10B981' : '#EF4444'}; font-weight:bold;">${inquiries} Hard Checks</span>
          </div>
          <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${Math.min(100, (inquiries/6)*100)}%; background:${inquiries > 2 ? '#EF4444' : '#10B981'};"></div></div>
        </div>
      </div>

      <!-- Actionable Improvement Suggestions -->
      <div style="background:rgba(37, 99, 235, 0.05); border:1px solid rgba(37, 99, 235, 0.2); border-radius:var(--radius-md); padding:1.25rem;">
        <h4 style="color:var(--primary-blue); font-size:1.05rem; margin-bottom:0.75rem;">💡 Personalized Improvement Plan</h4>
        <ul style="list-style:none; display:flex; flex-direction:column; gap:0.5rem; color:var(--text-secondary); font-size:0.9rem;">
          ${utilization > 30 ? '<li>• <strong>Reduce Credit Card Balance:</strong> Lower your card utilization below 30% to gain up to +25 score points.</li>' : ''}
          ${inquiries > 2 ? '<li>• <strong>Pause New Credit Applications:</strong> Space out credit applications by at least 6 months to stop hard inquiry penalties.</li>' : ''}
          <li>• <strong>Auto-Debit Payments:</strong> Ensure 100% on-time repayment history for existing EMIs and credit card statements.</li>
          <li>• <strong>Keep Old Accounts Open:</strong> Avoid closing your oldest credit card to preserve credit history length.</li>
        </ul>
      </div>

      <p style="margin-top:1.25rem; font-size:0.8rem; color:var(--text-muted); text-align:center;">
        * Credit scoring models vary by bureau (CIBIL, Experian, Equifax). The analysis displayed above is an educational estimation.
      </p>
    </div>
  `;

  resultContainer.scrollIntoView({ behavior: 'smooth' });

  // Animate Gauge Arc & Number Counter
  setTimeout(() => {
    const arc = document.getElementById('gauge-arc');
    if (arc) arc.style.strokeDashoffset = dashOffset;
    animateCounter(document.getElementById('gauge-score-val'), score, false, 1200);
  }, 100);

  showToast('Credit analysis generated successfully!', 'success');
}
