/**
 * AI LOAN ELIGIBILITY CHECKER - GOOGLE SHEETS & LOCAL STORAGE PERSISTENCE
 */

window.submitToSheets = async function(data) {
  try {
    const response = await fetch('/api/sheets/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const resData = await response.json();

    // Store in browser localStorage regardless as a reliable local record
    const existing = JSON.parse(localStorage.getItem('finvision_submissions') || '[]');
    existing.push({
      timestamp: new Date().toISOString(),
      ...data
    });
    localStorage.setItem('finvision_submissions', JSON.stringify(existing));

    if (resData && resData.mode === 'google_sheets') {
      showToast('Record synced to Google Sheets!', 'success');
    } else {
      showToast('Record saved securely in local storage.', 'info');
    }
  } catch (err) {
    console.warn('Sheets API offline, saving to local storage fallback:', err.message);
    const existing = JSON.parse(localStorage.getItem('finvision_submissions') || '[]');
    existing.push({
      timestamp: new Date().toISOString(),
      ...data
    });
    localStorage.setItem('finvision_submissions', JSON.stringify(existing));
    showToast('Record stored in browser storage.', 'info');
  }
};
